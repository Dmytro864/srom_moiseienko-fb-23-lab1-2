import time

class BigInt:
    MAX_BITS = 2048

    def __init__(self, value=0):
        if isinstance(value, str):
            self.value = int(value, 0)  
        elif isinstance(value, BigInt):
            self.value = value.value
        else:
            self.value = int(value)
        self._truncate()

    def _truncate(self):
        self.value &= (1 << self.MAX_BITS) - 1  

    @classmethod
    def from_hex(cls, hex_str):
        return cls(int(hex_str, 16))

    def to_hex(self):
        return hex(self.value)

    def to_bin(self):
        return bin(self.value)

    def to_dec(self):
        return str(self.value)

    def __add__(self, other):
        return BigInt(self.value + other.value)

    def __sub__(self, other):
        return BigInt(self.value - other.value)

    def __mul__(self, other):
        return BigInt(self.value * other.value)

    def __floordiv__(self, other):
        return BigInt(self.value // other.value)

    def __mod__(self, other):
        return BigInt(self.value % other.value)

    def __pow__(self, exponent):
        return BigInt(pow(self.value, exponent.value))

    def pow_mod(self, exponent, modulus):
        return BigInt(pow(self.value, exponent.value, modulus.value))

    def __lshift__(self, bits):
        return BigInt(self.value << bits)

    def __rshift__(self, bits):
        return BigInt(self.value >> bits)

    def msb_index(self):
        return self.value.bit_length() - 1 if self.value > 0 else 0

    def __str__(self):
        return self.to_hex()

    def __repr__(self):
        return f"BigInt({self.to_hex()})"


def test_identities():
    print("=== Перевірка арифметичних тотожностей ===")
    a = BigInt(12345678901234567890)
    b = BigInt(98765432109876543210)
    c = BigInt(11111111111111111111)

    # (a + b) * c == a * c + b * c
    left = (a + b) * c
    right = a * c + b * c
    print("1. (a + b) * c == a * c + b * c")
    print("   Ліва частина:", left)
    print("   Права частина:", right)
    print("   Результат:", "OK" if left.value == right.value else "FAIL")

    n = 100
    sum_a = BigInt(0)
    for _ in range(n):
        sum_a = sum_a + a
    mul_a = a * BigInt(n)
    print("\n2. a + a + ... (n разів) == a * n (n = 100)")
    print("   Через додавання:", sum_a)
    print("   Через множення:", mul_a)
    print("   Результат:", "OK" if sum_a.value == mul_a.value else "FAIL")


def benchmark_operations(iterations=1000):
    print("\n=== Вимірювання часу виконання операцій ===")
    import random

    def random_bigint():
        return BigInt(random.getrandbits(2048))

    operations = {
        "Додавання": lambda x, y: x + y,
        "Віднімання": lambda x, y: x - y,
        "Множення": lambda x, y: x * y,
        "Ділення": lambda x, y: x // y,
        "Остача": lambda x, y: x % y,
        "Піднесення до квадрату": lambda x, _: x ** BigInt(2),
        "Зсув вліво": lambda x, _: x << 5,
        "Зсув вправо": lambda x, _: x >> 5,
        "Піднесення до степеня (мод)": lambda x, y: x.pow_mod(BigInt(3), y),
    }

    results = {}
    for name, op in operations.items():
        total_time = 0
        for _ in range(iterations):
            x = random_bigint()
            y = random_bigint()
            start = time.perf_counter()
            op(x, y)
            end = time.perf_counter()
            total_time += (end - start)
        avg_time = total_time / iterations
        results[name] = avg_time * 1e6  

    print(f"{'Операція':<35} | {'Середній час (мкс)':>20}")
    print("-" * 60)
    for name, avg in results.items():
        print(f"{name:<35} | {avg:>20.2f}")


if __name__ == "__main__":
    test_identities()
    benchmark_operations()
